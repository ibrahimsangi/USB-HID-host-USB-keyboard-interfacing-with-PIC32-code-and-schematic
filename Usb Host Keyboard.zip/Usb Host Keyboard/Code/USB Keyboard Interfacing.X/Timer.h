
/*
 * File:   Timer.h
 *
 * Author: IBRAHIM LABS
 *
 * Website: http://ibrahimlabs.blogspot.com/
 *
 * Created on September 22, 2013, 7:43 AM
 */

#ifndef TIMER_H
#define	TIMER_H

#ifdef	__cplusplus
extern "C" {
#endif


void InitializeTimer( void );

#ifdef	__cplusplus
}
#endif

#endif	/* TIMER_H */

